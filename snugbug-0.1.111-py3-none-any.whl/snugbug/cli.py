import argparse
import sys
from pathlib import Path

from snugbug.secret_scanner import SecretScanner
from snugbug.git_secrets_cleaner import GitSecretsCleaner
from snugbug.pre_commit_guard import PreCommitGuard
from snugbug.secret_guardian import SecretGuardian

def create_parser():
    parser = argparse.ArgumentParser(
        prog='snugbug',
        description='Snug Bug - Yet another Git secret management toolkit',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  snugbug scan --all --confidence MEDIUM     
  snugbug scan --recent 50 --confidence HIGH     
  snugbug scan --branch main --confidence HIGH  
  snugbug clean --confidence HIGH
  snugbug clean --dry-run --confidence MEDIUM
  snugbug guard --install --confidence HIGH
  snugbug guard --check-staged --confidence MEDIUM
  snugbug protect --recent 100 --confidence HIGH
        '''
    )
    
    parser.add_argument('--version', action='version', version='Secret Guardian 1.0.0')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    ## scan
    scan_parser = subparsers.add_parser(
        'scan', 
        help='Scan git history for secrets',
        description='Scan git repository for potential secrets using patterns and entropy analysis'
    )
    scan_group = scan_parser.add_mutually_exclusive_group(required=True)
    scan_group.add_argument('--all', action='store_true', help='Scan all commits across all branches')
    scan_group.add_argument('--recent', type=int, metavar='N', help='Scan last N commits on current branch')
    scan_group.add_argument('--branch', metavar='BRANCH', help='Scan all commits on specific branch (without switching)')
    
    scan_parser.add_argument('--output', '-o', default='.secrets_report.json', 
                           help='Output JSON file (default: .secrets_report.json)')
    scan_parser.add_argument('--entropy', type=float, default=4.5,
                           help='Entropy threshold for detection (default: 4.5)')
    scan_parser.add_argument('--confidence', choices=['HIGH', 'MEDIUM', 'LOW', 'VERY_LOW'], 
                           default='LOW', help='Minimum confidence level to report (default: LOW)')

    # clean
    clean_parser = subparsers.add_parser(
        'clean',
        help='Clean secrets from git history', 
        description='Remove secrets from git history'
    )
    clean_parser.add_argument('--report', '-r', default='.secrets_report.json',
                            help='Path to secrets report JSON file')
    clean_parser.add_argument('--dry-run', action='store_true',
                            help='Show what would be done without executing')
    clean_parser.add_argument('--method', 
                            choices=['simple', 'advanced'], 
                            default='simple',
                            help='Cleaning method (simple=current files, advanced=full history)')
    clean_parser.add_argument('--confidence', choices=['HIGH', 'MEDIUM', 'LOW', 'VERY_LOW'], 
                             default='MEDIUM', help='Minimum confidence level to clean (default: MEDIUM)')
    
    # guard
    guard_parser = subparsers.add_parser(
        'guard', 
        help='Prevent secrets in future commits',
        description='Install and manage pre-commit hooks to prevent secrets'
    )
    guard_group = guard_parser.add_mutually_exclusive_group(required=True)
    guard_group.add_argument('--install', action='store_true', 
                           help='Install pre-commit hook')
    guard_group.add_argument('--check-staged', action='store_true',
                           help='Check staged files for secrets')
    guard_group.add_argument('--check-files', nargs='+', metavar='FILE',
                           help='Check specific files for secrets')
    guard_group.add_argument('--check-dir', metavar='DIR', 
                           help='Check directory for secrets')
    guard_parser.add_argument('--strict', action='store_true',
                            help='Strict mode (block commits for any violation)')
    guard_parser.add_argument('--entropy', type=float, default=4.5,
                            help='Entropy threshold (default: 4.5)')
    guard_parser.add_argument('--confidence', choices=['HIGH', 'MEDIUM', 'LOW', 'VERY_LOW'], 
                            default='MEDIUM', help='Minimum confidence level to block commits (default: MEDIUM)')
    
    # protect
    protect_parser = subparsers.add_parser(
        'protect',
        help='Complete protection workflow',
        description='Full workflow: scan for secrets, clean history, and setup protection'
    )
    protect_parser.add_argument('--recent', type=int, metavar='N',
                              help='Only scan last N commits (default: all commits)')
    protect_parser.add_argument('--dry-run', action='store_true',
                              help='Show what would be done without executing')
    protect_parser.add_argument('--method', 
                              choices=['simple', 'advanced'], 
                              default='simple',
                              help='Cleaning method (simple=current files, advanced=full history)')
    protect_parser.add_argument('--report', default='.secrets_report.json',
                              help='Path to secrets report file')
    protect_parser.add_argument('--confidence', choices=['HIGH', 'MEDIUM', 'LOW', 'VERY_LOW'], 
                              default='MEDIUM', help='Minimum confidence level for operations (default: MEDIUM)')
    
    return parser

def cmd_scan(args):
    print("Scanning repository for secrets...")
    
    scanner = SecretScanner(entropy_threshold=args.entropy)
    
    if args.all:
        secrets = scanner.scan_commits(all_commits=True, min_confidence=args.confidence)
    elif args.recent:
        secrets = scanner.scan_commits(recent=args.recent, min_confidence=args.confidence)
    elif args.branch:
        secrets = scanner.scan_commits(target_branch=args.branch, min_confidence=args.confidence)
    
    report = scanner.generate_report(secrets, args.output)
    
    # different exit codes based on confidence levels
    if secrets:
        high_confidence_secrets = [s for s in secrets if s['confidence']['level'] == 'HIGH']
        if high_confidence_secrets:
            return 2  # high confidence secrets found
        else:
            return 1  # some secrets found but lower confidence
    else:
        return 0  # no secrets found

def cmd_clean(args):
    print("Cleaning secrets from git history...")
    
    cleaner = GitSecretsCleaner(dry_run=args.dry_run)
    
    if not cleaner.check_repo_clean():
        return 1
    
    secrets = cleaner.load_secrets(args.report)
    if secrets is None:
        return 1
    
    print(f"Cleaning secrets with {args.confidence}+ confidence")
    
    if args.method == "simple":
        success = cleaner.clean_history_simple(secrets, min_confidence=args.confidence)
    elif args.method == "advanced":
        success = cleaner.clean_history_advanced(secrets, min_confidence=args.confidence)
    else:
        print(f"Unknown method: {args.method}")
        return 1
    
    return 0 if success else 1

def cmd_guard(args):
    guard = PreCommitGuard(
        entropy_threshold=args.entropy,
        strict_mode=args.strict,
        min_confidence=args.confidence
    )
    
    if args.install:
        print("Installing pre-commit hook...")
        success = guard.install_git_hook()
        return 0 if success else 1
        
    elif args.check_staged:
        print("Checking staged files...")
        violations = guard.scan_staged_files()
        clean = guard.report_violations(violations)
        
        if violations:
            high_confidence_violations = [v for v in violations if v['confidence']['level'] == 'HIGH']
            if high_confidence_violations:
                return 2
            elif not clean:
                return 1
            else:
                return 0  # warning only
        else:
            return 0  # no violations
        
    elif args.check_files:
        print(f"Checking {len(args.check_files)} files...")
        violations = guard.scan_files(args.check_files)
        clean = guard.report_violations(violations)
        
        if violations:
            high_confidence_violations = [v for v in violations if v['confidence']['level'] == 'HIGH']
            if high_confidence_violations:
                return 2
            elif not clean:
                return 1
            else:
                return 0
        else:
            return 0
        
    elif args.check_dir:
        print(f"Checking directory: {args.check_dir}")
        py_files = list(Path(args.check_dir).glob("**/*.py"))
        violations = guard.scan_files([str(f) for f in py_files])
        clean = guard.report_violations(violations)
        
        if violations:
            high_confidence_violations = [v for v in violations if v['confidence']['level'] == 'HIGH']
            if high_confidence_violations:
                return 2
            elif not clean:
                return 1
            else:
                return 0
        else:
            return 0

def cmd_protect(args):
    print("Starting complete protection workflow...")
    
    guardian = SecretGuardian()
    guardian.report_file = args.report
    
    if not guardian.check_git_repo():
        return 1
    
    success = guardian.full_scan_and_clean(
        recent_commits=args.recent,
        dry_run=args.dry_run,
        method=args.method,
        min_confidence=args.confidence
    )
    
    return 0 if success else 1

def cmd_status(args):
    print("Repository Security Status")
    print("=" * 40)
    
    guardian = SecretGuardian()
    
    if not guardian.check_git_repo():
        print("Not in a git repository")
        return 1
    
    repo_info = guardian.get_repo_info()
    if repo_info:
        print(f"Branch: {repo_info['branch']}")
        print(f"Commits: {repo_info['commit_count']}")
        print(f"Remote: {repo_info['remote']}")
    
    hook_path = Path(".git/hooks/pre-commit")
    if hook_path.exists():
        print("Pre-commit hook: Installed")
    else:
        print("Pre-commit hook: Not installed")
        print("   Run: snugbug guard --install")
    
    report_path = Path(".secrets_report.json")
    if report_path.exists():
        try:
            import json
            with open(report_path) as f:
                report = json.load(f)
            secrets = report.get('secrets', [])
            secret_count = len(secrets)
            print(f"Last scan: {secret_count} secrets found")
            
            if secret_count > 0:
                from collections import defaultdict
                by_confidence = defaultdict(int)
                for secret in secrets:
                    if 'confidence' in secret:
                        confidence_level = secret['confidence']['level']
                        by_confidence[confidence_level] += 1
                
                print("Confidence breakdown:")
                for level in ['HIGH', 'MEDIUM', 'LOW', 'VERY_LOW']:
                    count = by_confidence[level]
                    if count > 0:
                        print(f"   {level}: {count}")
                
                high_count = by_confidence['HIGH']
                if high_count > 0:
                    print(f"URGENT: {high_count} HIGH confidence secrets need immediate attention!")
                    print("   Run: snugbug clean --confidence HIGH")
                else:
                    print("   Run: snugbug clean")
        except:
            print("Last scan: Report file corrupted")
    else:
        print("Last scan: No report found")
        print("   Run: snugbug scan --recent 50")
    
    print("\nQuick scan of current directory...")
    guard = PreCommitGuard(min_confidence="HIGH")
    py_files = list(Path(".").glob("*.py"))[:5]
    if py_files:
        violations = guard.scan_files([str(f) for f in py_files])
        if violations:
            high_confidence_violations = [v for v in violations if v['confidence']['level'] == 'HIGH']
            if high_confidence_violations:
                print(f"WARNING: {len(high_confidence_violations)} HIGH confidence secrets in current files")
            else:
                print(f"Found {len(violations)} potential secrets (low confidence)")
        else:
            print("No obvious secrets in current Python files")
    
    print("\nRecommendations:")
    print("   1. Run full scan: snugbug scan --all")
    print("   2. Install protection: snugbug guard --install --confidence HIGH") 
    print("   3. Clean high-confidence secrets: snugbug clean --confidence HIGH")
    print("   4. For full protection: snugbug protect --confidence HIGH")
    
    return 0

def main(argv=None):
    parser = create_parser()
    if argv is None:
        argv = sys.argv[1:]

    if not argv:
        parser.print_help()
        return 0

    try:
        args = parser.parse_args(argv)

        if args.command == 'scan':
            return cmd_scan(args)
        elif args.command == 'clean':
            return cmd_clean(args)
        elif args.command == 'guard':
            return cmd_guard(args)
        elif args.command == 'protect':
            return cmd_protect(args)
        elif args.command == 'status':
            return cmd_status(args)
        else:
            parser.print_help()
            return 1

    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}")
        return 1

if __name__ == '__main__':
    sys.exit(main())