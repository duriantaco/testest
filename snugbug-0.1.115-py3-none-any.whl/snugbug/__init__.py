__version__ = "1.0.0"

try:
    from snugbug.secret_guardian import SecretGuardian, main
    from snugbug.secret_scanner import SecretScanner
    from snugbug.git_secrets_cleaner import GitSecretsCleaner
    from snugbug.pre_commit_guard import PreCommitGuard
    
    __all__ = [
        'SecretGuardian',
        'SecretScanner', 
        'GitSecretsCleaner',
        'PreCommitGuard',
        'main'
    ]
    
except ImportError as e:
    print(f"Warning: Some modules could not be imported: {e}")
    __all__ = []