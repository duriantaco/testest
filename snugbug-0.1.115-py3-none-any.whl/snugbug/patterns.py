import re

PATTERNS = {
    "AWS_ACCESS_KEY"      : r"AKIA[0-9A-Z]{16}",
    "AWS_SECRET_KEY"      : r"[A-Za-z0-9/+=]{40}",
    "AWS_TEMP_ACCESS_KEY" : r"ASIA[0-9A-Z]{16}",
    "Stripe_Live" : r"sk_live_[0-9A-Za-z]{24,32}",
    "Stripe_Test" : r"sk_test_[0-9A-Za-z]{24,32}",
    "OpenAI"      : r"sk-[A-Za-z0-9_-]{20,}",
    "OpenAI_Org"  : r"org-[A-Za-z0-9]{24}",
    "Anthropic"   : r"sk-ant-api03-[A-Za-z0-9_-]{40,}",
    "Deepseek"    : r"sk-[A-Za-z0-9]{20,25}",
    "Google_API"       : r"AIza[0-9A-Za-z_-]{35}",
    "Firebase_API_Key" : r"AIza[0-9A-Za-z_-]{35}",
    "Twilio_Account_SID" : r"AC[a-fA-F0-9]{32}",
    "Twilio_Auth_Token"  : r"[A-Fa-f0-9]{32}",
    "SendGrid_API_Key"   : r"SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}",
    "Discord_Bot_Token"  : r"[MNO][A-Za-z\d_-]{23,25}\.[A-Za-z\d_-]{6}\.[A-Za-z\d_-]{27,39}",
    "GitHub_Token" : r"ghp_[A-Za-z0-9]{36}",
    "Bearer_Token" : r"[Bb]earer\s+[A-Za-z0-9+/=]{20,}",
    "JWT"          : r"eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*",
    "Private_Key"  : r"-----BEGIN [A-Z ]+PRIVATE KEY-----",
}

ENTROPY_REGEX = re.compile(r"[A-Za-z0-9+/=#@!$%^&*_~\-]{32,}") 

FALSE_POSITIVES = {
    "EXAMPLE_KEY", "YOUR_API_KEY_HERE", "xxxxxxxxxxxxxxxx", "[REDACTED]",
    
    "fake", "test", "sample", "demo", "mock", "example", "placeholder", 
    "dummy", "fakeuser", "testuser", "samplekey", "demokey",
    
    "your_key_here", "insert_key_here", "replace_with_your_key",
    "api_key_here", "secret_here", "token_here",
}

def is_false_positive(token: str) -> bool:
    token_upper = token.upper()
    token_lower = token.lower()
    
    if any(fp.upper() in token_upper for fp in FALSE_POSITIVES):
        return True
    
    test_indicators = ['fake', 'test', 'sample', 'demo', 'mock', 'example', 'dummy']
    if any(indicator in token_lower for indicator in test_indicators):
        return True
    
    if len(token) == 40 and all(c in '0123456789abcdefABCDEF' for c in token):
        return True
    if len(token) == 64 and all(c in '0123456789abcdefABCDEF' for c in token):
        return True
    
    if any(pattern in token_upper for pattern in ['REDACTED', '[REDACTED]', 'XXXXX']):
        return True
    
    if len(set(token)) == 1:
        return True
    
    return False

__all__ = ["PATTERNS", "ENTROPY_REGEX", "FALSE_POSITIVES", "is_false_positive"]
