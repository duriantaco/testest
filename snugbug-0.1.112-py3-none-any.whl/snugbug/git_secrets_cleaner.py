import json
import subprocess
import os
import sys
from collections import defaultdict
from snugbug.secret_scanner import SecretScanner

class GitSecretsCleaner:
    def __init__(self, dry_run=False):
        self.dry_run = dry_run
        self.temp_dir = None
        
    def check_repo_clean(self):
        try:
            result = subprocess.run(["git", "status", "--porcelain"], 
                                  capture_output=True, text=True)
            if result.stdout.strip():
                print("Repository has uncommitted changes. Please commit or stash first.")
                return False
            return True
        
        except subprocess.CalledProcessError:
            print("Not in a git repository")
            return False
    
    def create_backup(self):
        try:
            current_branch = subprocess.check_output(
                ["git", "branch", "--show-current"], text=True
            ).strip()
            
            backup_name = f"backup-before-secret-clean-{current_branch}"
            
            try:
                subprocess.run(["git", "branch", "-D", backup_name], 
                             capture_output=True, check=False)
            except:
                pass
            
            subprocess.run(["git", "branch", backup_name], check=True)
            print(f"Created backup: {backup_name}")
            return backup_name
            
        except subprocess.CalledProcessError as e:
            print(f"Could not create backup: {e}")
            return None
    
    def filter_secrets_by_confidence(self, secrets, min_confidence="MEDIUM"):
        confidence_order = {"VERY_LOW": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3}
        min_level = confidence_order.get(min_confidence, 2)
        
        filtered_secrets = []
        skipped_count = 0
        
        for secret in secrets:
            secret_level = confidence_order.get(secret['confidence']['level'], 0)
            if secret_level >= min_level:
                filtered_secrets.append(secret)
            else:
                skipped_count += 1
                    
        if skipped_count > 0:
            print(f"Skipped {skipped_count} low-confidence detections")
            
        return filtered_secrets
    
    def get_all_commits(self):
        """Get all commit hashes"""
        try:
            result = subprocess.check_output(
                ["git", "rev-list", "--all", "--reverse"],
                text=True
            )
            return result.strip().split('\n') if result.strip() else []
        except subprocess.CalledProcessError:
            return []
    
    def get_commit_files(self, commit_hash):
        try:
            result = subprocess.check_output(
                ["git", "ls-tree", "-r", "--name-only", commit_hash],
                text=True
            )
            return result.strip().split('\n') if result.strip() else []
        except subprocess.CalledProcessError:
            return []
    
    def get_file_content(self, commit_hash, file_path):
        try:
            return subprocess.check_output(
                ["git", "show", f"{commit_hash}:{file_path}"],
                text=True, errors="ignore"
            )
        except subprocess.CalledProcessError:
            return None
    
    def apply_replacements(self, content, replacements):
        """Apply secret replacements to content"""
        modified_content = content
        replacements_made = []
        
        for secret_token, replacement in replacements.items():
            if secret_token in modified_content:
                modified_content = modified_content.replace(secret_token, replacement)
                replacements_made.append((secret_token, replacement))
        
        return modified_content, replacements_made
    
    def clean_history_simple_from_memory(self, secrets, min_confidence="MEDIUM"):
        replacements = {}
        for secret in secrets:
            token = secret['token']
            conf_level = secret['confidence']['level']
            replacement = f"[REDACTED_{conf_level}_{token[:4]}...{token[-4:]}]"
            replacements[token] = replacement
        
        backup = self.create_backup()
        
        affected_files = set()
        for secret in secrets:
            affected_files.add(secret['file'])
        
        print(f"Processing {len(affected_files)} affected files...")
        
        files_modified = []
        for file_path in affected_files:
            if not os.path.exists(file_path):
                continue
                
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            modified_content, replacements_made = self.apply_replacements(content, replacements)
            
            if replacements_made:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(modified_content)
                files_modified.append((file_path, len(replacements_made)))
                print(f"   {file_path}: {len(replacements_made)} secrets replaced")
        
        if files_modified:
            subprocess.run(["git", "add"] + [f[0] for f in files_modified], check=True)
            subprocess.run(["git", "commit", "-m", f"Remove {len(secrets)} secrets (confidence: {min_confidence}+)"], check=True)
            
            print(f"\nSuccessfully cleaned {len(files_modified)} files!")
            print(f"Cleaned {len(secrets)} secrets with {min_confidence}+ confidence")
            print("\nNext steps:")
            print("   1. Review changes: git show HEAD")
            print("   2. Push if needed: git push --force-with-lease")
            if backup:
                print(f"   3. Delete backup when satisfied: git branch -D {backup}")
            return True
        else:
            print("No files were modified")
            return True
        
    def clean_history_simple(self, secrets, min_confidence="MEDIUM"):
        """simple cleaning with confidence filtering"""
        if not secrets:
            print("No secrets to clean")
            return True
        
        filtered_secrets = self.filter_secrets_by_confidence(secrets, min_confidence)
        
        if not filtered_secrets:
            print(f"No secrets found with {min_confidence}+ confidence")
            return True
        
        # group by confidence for better reporting
        by_confidence = defaultdict(list)
        for secret in filtered_secrets:
            confidence_level = secret['confidence']['level']
            by_confidence[confidence_level].append(secret)
        
        print(f"Cleaning {len(filtered_secrets)} secrets with {min_confidence}+ confidence...")
        
        for level in ['HIGH', 'MEDIUM', 'LOW', 'VERY_LOW']:
            count = len(by_confidence[level])
            if count > 0:
                print(f"   {level}: {count} secrets")
        
        replacements = {}
        for secret in filtered_secrets:
            token = secret['token']
            conf_level = secret['confidence']['level']
            replacement = f"[REDACTED_{conf_level}_{token[:4]}...{token[-4:]}]"
            replacements[token] = replacement
        
        print("Replacements to be made:")
        for i, (token, replacement) in enumerate(replacements.items(), 1):
            # get confidence level for this token
            confidence_level = "UNKNOWN"
            for secret in filtered_secrets:
                if secret['token'] == token:
                    confidence_level = secret['confidence']['level']
                    break
            
            print(f"  {i}. [{confidence_level}] {token[:10]}... → {replacement}")
        
        if self.dry_run:
            print("\nDRY RUN - Would clean these files:")
            for secret in filtered_secrets:
                file_path = secret['file']
                line_num = secret['line']
                token = secret['token']
                confidence = secret['confidence']['level']
                print(f"   {file_path}:{line_num} - {token[:10]}... ({confidence})")
            return True
        
        confirm = input(f"\nThis will clean {len(filtered_secrets)} secrets from history. Continue? (y/N): ")
        if confirm.lower() != 'y':
            print("Cancelled")
            return False
        
        backup = self.create_backup()
        
        affected_files = set()
        for secret in filtered_secrets:
            affected_files.add(secret['file'])
        
        print(f"\nProcessing {len(affected_files)} affected files...")
        
        files_modified = []
        
        for file_path in affected_files:
            if not os.path.exists(file_path):
                continue
                
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            modified_content, replacements_made = self.apply_replacements(content, replacements)
            
            if replacements_made:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(modified_content)
                files_modified.append((file_path, len(replacements_made)))
                print(f"   {file_path}: {len(replacements_made)} secrets replaced")
        
        if files_modified:
            subprocess.run(["git", "add"] + [f[0] for f in files_modified], check=True)
            subprocess.run(["git", "commit", "-m", f"Remove {len(filtered_secrets)} secrets (confidence: {min_confidence}+)"], check=True)
            
            print(f"\nSuccessfully cleaned {len(files_modified)} files!")
            print(f"Cleaned {len(filtered_secrets)} secrets with {min_confidence}+ confidence")
            print("\nNext steps:")
            print("   1. Review changes: git show HEAD")
            print("   2. Push if needed: git push --force-with-lease")
            print("   3. Regenerate all cleaned API keys")
            if backup:
                print(f"   4. Delete backup when satisfied: git branch -D {backup}")
        else:
            print("No files were modified (secrets may already be cleaned)")
        ok = self._verify_history_is_clean(min_confidence="HIGH")
        return ok
    
    def clean_history_advanced(self, secrets, min_confidence="MEDIUM"):
  
        if not secrets:
            print("No secrets to clean")
            return True

        filtered_secrets = self.filter_secrets_by_confidence(secrets, min_confidence)
        if not filtered_secrets:
            print(f"No secrets found with {min_confidence}+ confidence")
            return True

        replacements = {
            s['token']: f"[REDACTED_{s['confidence']['level']}_{s['token'][:4]}...{s['token'][-4:]}]"
            for s in filtered_secrets
        }

        print(f"Advanced cleaning: git-filter-repo will scrub {len(replacements)} secrets …")
        if self.dry_run:
            for old, new in replacements.items():
                print(f"   {old[:10]}...  →  {new}")
            print("\nDRY RUN — no history rewritten")
            return True

        if not self.check_repo_clean():
            return False
        backup = self.create_backup()

        try:
            from git_filter_repo import FilterRepo, Blob
        except ImportError:
            print("git-filter-repo not found.  pip install git-filter-repo")
            return False

        def scrub_blob(blob: Blob, _metadata):
            """Replace tokens in every text blob; skip binaries."""
            if blob.is_binary:
                return
            data = blob.data.decode('utf-8', 'ignore')
            for old, new in replacements.items():
                if old in data:
                    data = data.replace(old, new)
            blob.data = data.encode('utf-8')

        print("Rewriting history … this may take a moment")
        FilterRepo.run(
            filter_blobs=scrub_blob,
            replace_refs=True
        )
        ok = self._verify_history_is_clean(min_confidence="HIGH")


        print(f"\nHistory rewritten!  Scrubbed {len(replacements)} secrets")
        print("Next steps:")
        print("  1. Review: git log --oneline")
        print("  2. Force-push: git push --force-with-lease")
        print("  3. Invalidate / rotate the redacted credentials")
        if backup:
            print(f"  4. Delete backup branch when satisfied: git branch -D {backup}")
        return ok

    def _verify_history_is_clean(self, min_confidence="HIGH") -> bool:
        print("\nVerifying cleaned history …")
        scanner = SecretScanner()
        try: 
            leftover = scanner.scan_commits(all_commits=True,
                                        min_confidence=min_confidence)
        
        except KeyboardInterrupt:
            print("\nVerification cancelled by user")
            return False
        
        if leftover:
            print(f"❌  {len(leftover)} secret(s) still detected after rewrite!")
            for s in leftover:
                print(f"   {s['type']}: {s['token'][:6]}…{s['token'][-4:]} "
                    f"(commit {s['commit'][:7]}, file {s['file']})")
            return False

        print("✅  Post-clean scan shows no remaining secrets.")
        return True

    def load_secrets(self, report_file):
        try:
            with open(report_file, 'r') as f:
                report = json.load(f)
                
            secrets = report.get('secrets', [])
            
            # should display confidence summary if avail
            if secrets and isinstance(secrets[0], dict) and 'confidence' in secrets[0]:
                by_confidence = defaultdict(int)
                for secret in secrets:
                    confidence_level = secret['confidence']['level']
                    by_confidence[confidence_level] += 1
                    
                print(f"Loaded {len(secrets)} secrets from report:")
                for level in ['HIGH', 'MEDIUM', 'LOW', 'VERY_LOW']:
                    count = by_confidence[level]
                    if count > 0:
                        print(f"   {level}: {count}")
                        
            return secrets
            
        except FileNotFoundError:
            print(f"Report file not found: {report_file}")
            print("Run the scanner first to generate the report.")
            return None
        except json.JSONDecodeError as e:
            print(f"Invalid JSON in report: {e}")
            return None

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Enhanced Git History Cleaner with Confidence Support")
    parser.add_argument("--report", "-r", default=".secrets_report.json",
                       help="Secrets report file")
    parser.add_argument("--dry-run", action="store_true",
                       help="Show what would be done")
    parser.add_argument("--method", choices=["simple", "advanced"], default="simple",
                       help="Cleaning method (simple=current files, advanced=full history)")
    parser.add_argument("--confidence", choices=["HIGH", "MEDIUM", "LOW", "VERY_LOW"], 
                       default="MEDIUM", help="Minimum confidence level to clean (default: MEDIUM)")
    
    args = parser.parse_args()
    
    cleaner = GitSecretsCleaner(dry_run=args.dry_run)
    
    if not cleaner.check_repo_clean():
        sys.exit(1)
    
    secrets = cleaner.load_secrets(args.report)
    if secrets is None:
        sys.exit(1)
    
    if not secrets:
        print("No secrets found in report")
        sys.exit(0)
    
    print(f"Cleaning secrets with {args.confidence}+ confidence")
    
    if args.method == "simple":
        success = cleaner.clean_history_simple(secrets, min_confidence=args.confidence)
    else:
        success = cleaner.clean_history_advanced(secrets, min_confidence=args.confidence)
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()